$('.alert').alert()
